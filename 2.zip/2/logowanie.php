<?php



session_start();

   
	
	if ((!isset($_POST['login'])) || (!isset($_POST['haslo'])))
	
    {
		header('Location: index.html');
		exit();
	}


	
	



$login=$_POST['login']; 
$haslo=$_POST['haslo']; 
$link = mysqli_connect(------------------------------------); 

	
if(!$link){

	echo"Blad: ". mysqli_connect_errno()." ".mysqli_connect_error(); 
	} 
	
	

$result = mysqli_query($link, "SELECT * FROM ----- WHERE ------'"); 
$rekord = mysqli_fetch_array($result); 

	if(!$rekord) 
	{
	mysqli_close($link); 
	echo "BRAK TAKIEGO LOGINU";
	}

		else {
            
		if($rekord['haslo']==$haslo) {
            
            
                $_SESSION['zalogowany'] = true;
                $_SESSION['nazwakonta'] = $rekord['nazwa'];
                
				
				
				unset($_SESSION['blad']);
				$result->free_result();
				
		
            header('Location: wybor.php');
		}
		else
		{
		mysqli_close($link);
		echo "ZLE HASLO"; 
		}
		}
?>
