<html>
    
	<head>
	</head>
        
		<body>
      
            <form method="post" action="rejestracja.php">

                    <div id="nazwa">
                    Nazwa konta:<input type="text" name="nazwa" maxlength="10" size="20"><br> 
                    </div>

					<div id="login">
                    Login:<input type="text" name="login" maxlength="10" size="20"><br> 
                    </div>
					
                    <div id="haslo">
                    Haslo:<input type="password" name="haslo" maxlength="10" size="20"><br>
                    </div>

                    <div id="przycisk">
                    <input type="submit" value="zarejestruj"/>
                    </div>

            </form>
               
        </body>
</html>      

