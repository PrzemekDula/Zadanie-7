<?php
session_start();

   
	
	if ((!isset($_POST['login'])) || (!isset($_POST['haslo'])))
	
    {
		header('Location: index.html');
		exit();
	}
?>


<html>
	
	<body>
		
		<form action="odbierz.php" method="POST"
		
			ENCTYPE="multipart/form-data">
			<input type="file" name="plik"/>
			<input type="submit" value="Wyslij plik"/>
		
		</form>
		
		
		<br><p></p>
		<br><p></p>
		<br><p></p>
		<br><p></p>
		<br><p></p>
		<br><p></p>
		<br><p></p>
		<br><p></p>
		
		
		<div id="wroc">   <a href="wybor.php"><input type="submit" value="Powrot"></a> </div>
		
		
	</body>
 
 </html>