<?php
session_start();

   
	
	if ((!isset($_POST['login'])) || (!isset($_POST['haslo'])))
	
    {
		header('Location: index.html');
		exit();
	}
?>

<html>

    <head>	
	</head>

	<body>
	
		<div id="dodaj">   <a href="dodaj.php"><input type="submit" value="upload"></a> </div>
		
	    <div id="dodaj">   <a href="zobacz.php"><input type="submit" value="zobacz pliki"></a> </div>

		<div id="pobierz"> <a href="pobierz.php"><input type="submit" value="download "></a> </div>
	
	</body>





</html>
