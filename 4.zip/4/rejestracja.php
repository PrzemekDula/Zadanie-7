<?php



    $mysql_server = "-----------";
    $mysql_admin = "-----------";
    $mysql_pass = "-----------";
    $mysql_db = "-------------";
    
    @mysql_connect($mysql_server, $mysql_admin, $mysql_pass) or die ('BRAK POLACZENIA Z SERWEREM MySQL');
    @mysql_select_db($mysql_db) or die ('BLAD WYBORU BAZY DANYCH');  

     $nazwa = $_POST['nazwa'];
     $login = $_POST['login'];
	 $haslo = $_POST['haslo'];
	 
   $wynik = mysql_query("INSERT INTO users------------- VALUES --------------) ") or die ('BLAD ZAPYTANIA');
   

   

?>

<html>

	<head>
	</head>

	<body>
	
	<h2>Użytkownik pomyslnie dodany do bazy</h2>
	<br>
	<p></p>
	<h2>Wroc do panelu logowania by zalogowac sie na swoje nowe konto</h2>
	
	<div id="rejestracja">
	
	<a href="panlog.php"><input type="submit" value="Panel logowania"></a> 
	
	</div>
	
	
	
	
	</body>

</html>