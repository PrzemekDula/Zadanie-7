<?php


session_start();

   
	
	if ((!isset($_POST['login'])) || (!isset($_POST['haslo'])))
	
    {
		header('Location: index.html');
		exit();
	}





$dir = opendir('-------------------------------------------');
while(false !== ($file = readdir($dir)))
  if($file != '.' && $file != '..') 
  {
    echo $file . '<br />';       



  echo '<a href="download.php?file='.$file.'">Pobierz ten plik</a>' . '<br />';  
  echo "<br><p></p>";                                               }                             
																			   
																			   
																			   
																			   
																			   
																			   
																			   
																			   
																			   

?>

