<?php 

session_start();

   
	
	if ((!isset($_POST['login'])) || (!isset($_POST['haslo'])))
	
    {
		header('Location: index.html');
		exit();
	}





	if (is_uploaded_file($_FILES['plik']['tmp_name'])) {
		echo 'Odebrano plik: '.$_FILES['plik']['name'].'<br/>';
		
		move_uploaded_file($_FILES['plik']['tmp_name'],
		
		$_SERVER['DOCUMENT_ROOT'].'/przemo/'.$_FILES['plik']['name']);
		}
		
		else {echo 'Blad przy przesylaniu danych!';}
?>

<html>

    <head>	
	</head>

	<body>
	
		<div id="wroc">   <a href="wybor.php"><input type="submit" value="Powrot"></a> </div>
	
	
	</body>





</html>

		
		