<html>
    
	<head>
    </head>
        
		<body>
      
			<form method="post" action="logowanie.php">

					<div id="login">
					Login:<input type="text" name="login" maxlength="10" size="20"><br> 
                    </div>

                    <div id="haslo">
                    Haslo:<input type="password" name="haslo" maxlength="10" size="20"><br>
                    </div>

                    <div id="przycisk">
                    <input type="submit" value="ZALOGUJ"/>
                    </div>

                </form>
               
        </body>
</html>      

